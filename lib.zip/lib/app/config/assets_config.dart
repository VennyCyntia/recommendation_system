class AssetsConfig{

}