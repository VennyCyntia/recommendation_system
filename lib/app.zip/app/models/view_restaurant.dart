class ItemMenu{
  String? pic;
  String? title;
  String? category;
  String? description;
  int? price;

  ItemMenu({this.pic, this.title, this.category, this.description, this.price});

  ItemMenu.fromJson(Map<String, dynamic> json) {
    pic = json['pic'];
    title = json['title'];
    category = json['category'];
    description = json['description'];
    price = json['price'];
  }
}