import 'package:flutter/material.dart';

class RestaurantContainer extends StatelessWidget {
  const RestaurantContainer({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
