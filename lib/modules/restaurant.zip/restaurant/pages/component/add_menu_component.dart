import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:multiselect/multiselect.dart';
import 'package:recommendation_system/app/config/theme_config.dart';
import 'package:recommendation_system/modules/restaurant/controller/restaurant_controller.dart';
import 'package:recommendation_system/modules/restaurant/controller/restaurant_menu_controller.dart';
import 'package:recommendation_system/modules/restaurant/pages/component/text_field_input_component.dart';

class AddMenuComponent extends GetView<RestaurantMenuController> {
  const AddMenuComponent({super.key});

  @override
  Widget build(BuildContext context) {
    var restaurantController = Get.find<RestaurantController>();
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Add Item'),
          centerTitle: true,
        ),
        body: Padding(
          padding: EdgeInsets.all(ThemeConfig().defaultSpacing),
          child: Column(
            children: [
              Align(
                alignment: Alignment.topRight,
                child: ElevatedButton.icon(
                  onPressed: (){},
                  style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(
                          horizontal: ThemeConfig().defaultSpacing),
                      backgroundColor: ThemeConfig.justGrey,
                      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(5.0)))),
                  label: Text('Add Item', style: ThemeConfig().textHeader5(color: ThemeConfig.justBlack)),
                  icon: const Icon(Icons.add, color: ThemeConfig.justBlack, size: 20),
                ),
              ),
              Expanded(
                child: ListView.builder(
                  padding: EdgeInsets.symmetric(vertical: ThemeConfig().defaultSpacing),
                  itemCount: controller.lsFormMenu.value.length,
                  itemBuilder: (context, index) {
                    return Container(
                      padding: EdgeInsets.all(ThemeConfig().biggerSpacing),
                      margin: EdgeInsets.only(top: ThemeConfig().biggerSpacing),
                      decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          borderRadius: const BorderRadius.all(Radius.circular(10.0))),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Align(
                              alignment: Alignment.topRight,
                              child: IconButton(
                                  onPressed: (){},
                                  icon: const Icon(Icons.delete))),
                          TextFieldInputComponent(
                              title: 'Title', keyboardType: TextInputType.text, txtController:
                          controller.lsFormMenu[index][0]),
                          TextFieldInputComponent(
                              title: 'Subtitle', keyboardType: TextInputType.text, txtController:
                          controller.lsFormMenu[index][1]),
                          SizedBox(height: ThemeConfig().defaultSpacing),
                          Padding(
                            padding: const EdgeInsets.only(bottom: 2.0),
                            child: Align(
                                alignment: Alignment.topLeft,
                                child: RichText(
                                  text: TextSpan(
                                    text: 'Category',
                                    style: ThemeConfig().textHeader4Thin(color: Colors.black),
                                    children: <TextSpan>[
                                      TextSpan(
                                          text: '*',
                                          style: ThemeConfig().textHeader5(color: Colors.red)),
                                    ],
                                  ),
                                )),
                          ),
                         DropdownButtonFormField<String>(
                              decoration: const InputDecoration(
                                  border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(10.0)),
                              ), contentPadding: EdgeInsets.all(8.0)),
                              value: controller.listCategory[0].value,
                              onChanged: (String? newValue) {
                                controller.selectedCategory.value = newValue!;
                              },
                              items: controller.listCategory
                          ),
                          SizedBox(width: ThemeConfig().biggerSpacing),
                          FieldDropDown(index: index, lengthIndex: 0),
                          FieldDropDown(index: index, lengthIndex: 1),
                          FieldDropDown(index: index, lengthIndex: 2),
                          FieldDropDown(index: index, lengthIndex: 3),
                          SizedBox(width: ThemeConfig().biggerSpacing),
                          TextFieldInputComponent(
                              title: 'Price',
                              keyboardType: TextInputType.number),
                          SizedBox(height: ThemeConfig().biggerSpacing),
                          Row(
                            children: [
                              Expanded(
                                child: Container(
                                    margin: EdgeInsets.only(
                                        right: ThemeConfig().defaultSpacing),
                                    decoration: BoxDecoration(
                                        color: Colors.grey,
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(
                                                ThemeConfig().defaultSpacing))),
                                    child: SizedBox.fromSize(
                                        size: const Size.fromRadius(40),
                                        // Image radius
                                        child: const Center(
                                            child: Text('No Photo')))),
                              ),
                              Expanded(
                                child: ElevatedButton(
                                  onPressed: () {},
                                  style: ElevatedButton.styleFrom(
                                      primary: Colors.blue,
                                      minimumSize: const Size.fromHeight(48),
                                      elevation: 0,
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(
                                              ThemeConfig().defaultSpacing))),
                                  child: Text('from gallery',
                                      style: ThemeConfig().textHeader5Bold(
                                          color: ThemeConfig.justWhite)),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  ElevatedButton(
                    onPressed: (){},
                    style: ElevatedButton.styleFrom(
                        padding: EdgeInsets.symmetric(
                            horizontal: ThemeConfig().defaultSpacing),
                        backgroundColor: Colors.green,
                        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(5.0)))),
                    child: Text('SAVE', style: ThemeConfig().textHeader5(color: ThemeConfig.justWhite)),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class FieldDropDown extends GetView<RestaurantMenuController> {
  int index;
  int lengthIndex;

  FieldDropDown({super.key, required this.index, required this.lengthIndex});

  @override
  Widget build(BuildContext context) {
    return  DropdownButtonFormField<String>(
            decoration: const InputDecoration(
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(10.0)),
                ), contentPadding: EdgeInsets.all(8.0)),
            value: controller.selectedDesc.value,
            onChanged: (String? newValue) {
              controller.onAddDesc(index, newValue!);
            },
            items: controller.lsDescription[lengthIndex]
        );
  }
}
