import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:recommendation_system/app/models/view_restaurant.dart';

class RestaurantMenuController extends GetxController {
  var formKey = GlobalKey<FormState>();

  var selected = List<String>.empty(growable: true).obs;
  var lsFormMenu =
      List<List<TextEditingController>>.empty(growable: true).obs;

  var editFieldMenu =
      List<TextEditingController>.empty(growable: true).obs;

  var lsMenu = List<ViewMenu>.empty(growable: true).obs;

  var selectedCategory = 'Menu utama'.obs;
  var selectedDesc = 'NASI'.obs;
  var selectedDescription = List<String>.empty(growable: true).obs;

  List<DropdownMenuItem<String>> listCategory = [
    const DropdownMenuItem(child: Text("Menu utama"), value: "Menu utama"),
    const DropdownMenuItem(child: Text("Menu pendamping"), value: "Menu pendamping"),
    const DropdownMenuItem(child: Text("Minuman"), value: "Minuman"),
  ];

  var lsDescription = {
    0: [DropdownMenuItem(child: Text("NASI"), value: "NASI"),DropdownMenuItem(child: Text("MIE"), value: "MIE")],
    1: [DropdownMenuItem(child: Text("NASI"), value: "NASI"),DropdownMenuItem(child: Text("MIE"), value: "MIE")],
    2: [DropdownMenuItem(child: Text("NASI"), value: "NASI"),DropdownMenuItem(child: Text("MIE"), value: "MIE")],
    3: [DropdownMenuItem(child: Text("NASI"), value: "NASI"),DropdownMenuItem(child: Text("MIE"), value: "MIE")],
  }.obs;

  var isLoading = false.obs;

  @override
  void onInit() async {
    isLoading.value = true;
    onInitialAddForm();
    isLoading.value = false;
    super.onInit();
  }

  onAddDesc(int index, String value) {
    selectedDescription.add(value);
    lsFormMenu[index][3].text = selectedDescription.toString();
    print('selected '+lsFormMenu[index][3].text);
  }

  onInitialAddForm(){
    lsFormMenu.add(List.generate(7, (index) => TextEditingController()));
  }

  Future<void> onSaveRestaurant() async {
    // if(formKey.currentState!.validate()){
    //   List<ItemMenu> tempMenu = [];
    //
    //   for(int i=0; i<lsFormMenu.length; i++){
    //     tempMenu.add(ItemMenu(
    //       title: lsFormMenu[i][0].text,
    //       description: lsFormMenu[i][1].text,
    //       category: lsFormMenu[i][2].text,
    //       price: int.parse(lsFormMenu[i][3].text),
    //       pic: lsPic[i],
    //     ));
    //   }
    //   // await RestaurantDatabase.instance.insertRestaurant(tempEmployee);
    //   onGetAllData();
    // }
  }

  Future<void> onShowEditMenu({required int index}) async {
    // ViewEmployee employee = await RestaurantDatabase.instance.selectRestaurantByID(id: index);

    if(lsFormMenu.isNotEmpty){
      List<int> menuID = [];
      lsFormMenu.clear();
      // menuID[0] = employee.id
      // lsFormEmployee[0][0].text = employee.name!;
      // lsFormEmployee[0][1].text = employee.email!;
      // lsFormEmployee[0][2].text = employee.noTelepon!;
      // lsFormEmployee[0][3].text = employee.password!;
      // lsFormEmployee[0][4].text = employee.role!;
    }


  }

  Future<void> onGetAllData() async {
    // var employee = await RestaurantDatabase.instance.selectAllRestaurant();
    // for(var item in employee){
    //   lsEmployee.add(ViewEmployee.fromJson(item));
    // }
  }
}